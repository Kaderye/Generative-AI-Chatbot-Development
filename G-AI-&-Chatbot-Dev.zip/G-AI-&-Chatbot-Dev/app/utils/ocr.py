import base64
import pytesseract
from PIL import Image
import io

def extract_text_from_base64(image_base64: str) -> str:
    image_data = base64.b64decode(image_base64)
    image = Image.open(io.BytesIO(image_data))
    return pytesseract.image_to_string(image)
