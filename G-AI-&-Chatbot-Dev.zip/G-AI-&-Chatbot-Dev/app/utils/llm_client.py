import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()
client = OpenAI()

def construct_prompt(question: str, docs: list) -> str:
    context = "\n\n".join([doc["text"] for doc in docs])
    return f"Context:\n{context}\n\nQuestion: {question}"

def query_llm(prompt: str) -> str:
    res = client.chat.completions.create(
        model=os.getenv("LLM_MODEL", "gpt-3.5-turbo"),
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
    )
    return res.choices[0].message.content.strip()
