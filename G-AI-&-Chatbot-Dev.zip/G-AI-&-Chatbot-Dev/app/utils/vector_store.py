import faiss
import numpy as np
import uuid

index = faiss.IndexFlatL2(384)
documents = []

def save_to_vector_store(embeddings, chunks, metadata):
    global documents
    np_vectors = np.array(embeddings).astype("float32")
    index.add(np_vectors)
    for i, chunk in enumerate(chunks):
        meta = metadata[i]
        meta["text"] = chunk
        documents.append(meta)
    return str(uuid.uuid4())

def search_similar(query_embedding, top_k=3):
    np_vector = np.array(query_embedding).astype("float32").reshape(1, -1)
    D, I = index.search(np_vector, top_k)
    return [documents[i] for i in I[0]]
