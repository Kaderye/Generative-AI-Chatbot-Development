import os
from dotenv import load_dotenv
from openai import OpenAI
from sentence_transformers import SentenceTransformer

load_dotenv()

USE_OPENAI = os.getenv("EMBEDDING_MODEL", "").startswith("text-")
client = OpenAI()
model = SentenceTransformer("all-MiniLM-L6-v2") if not USE_OPENAI else None

def generate_embeddings(chunks: list) -> list:
    if USE_OPENAI:
        return [client.embeddings.create(input=chunk, model=os.getenv("EMBEDDING_MODEL")).data[0].embedding for chunk in chunks]
    else:
        return model.encode(chunks, convert_to_tensor=False).tolist()
