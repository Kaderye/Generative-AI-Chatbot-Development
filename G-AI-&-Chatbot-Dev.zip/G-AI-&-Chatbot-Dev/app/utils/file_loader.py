import os
import tempfile
from typing import Tuple, List
import fitz  # PyMuPDF
import docx
import pandas as pd
import pytesseract
from PIL import Image
import sqlite3

from app.utils.chunker import chunk_text

async def load_and_chunk(uploaded_file) -> Tuple[List[str], List[dict]]:
    ext = uploaded_file.filename.split(".")[-1].lower()
    content = ""

    with tempfile.NamedTemporaryFile(delete=False, suffix=f".{ext}") as tmp:
        tmp.write(await uploaded_file.read())
        tmp_path = tmp.name

    if ext == "pdf":
        content = extract_text_from_pdf(tmp_path)
    elif ext == "docx":
        content = extract_text_from_docx(tmp_path)
    elif ext == "txt":
        with open(tmp_path, 'r', encoding='utf-8') as f:
            content = f.read()
    elif ext in ["jpg", "jpeg", "png"]:
        content = extract_text_from_image(tmp_path)
    elif ext == "csv":
        content = extract_text_from_csv(tmp_path)
    elif ext == "db":
        content = extract_text_from_sqlite(tmp_path)
    else:
        raise ValueError("Unsupported file format.")

    os.unlink(tmp_path)
    chunks = chunk_text(content)
    metadata = [{"chunk_id": i, "source": uploaded_file.filename} for i in range(len(chunks))]
    return chunks, metadata

def extract_text_from_pdf(path):
    return "\n".join([page.get_text() for page in fitz.open(path)])

def extract_text_from_docx(path):
    doc = docx.Document(path)
    return "\n".join([para.text for para in doc.paragraphs])

def extract_text_from_image(path):
    return pytesseract.image_to_string(Image.open(path))

def extract_text_from_csv(path):
    df = pd.read_csv(path)
    return df.to_string(index=False)

def extract_text_from_sqlite(path):
    conn = sqlite3.connect(path)
    cursor = conn.cursor()
    tables = cursor.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()
    result = ""
    for (table_name,) in tables:
        df = pd.read_sql_query(f"SELECT * FROM {table_name}", conn)
        result += f"Table: {table_name}\n{df.to_string(index=False)}\n\n"
    conn.close()
    return result
