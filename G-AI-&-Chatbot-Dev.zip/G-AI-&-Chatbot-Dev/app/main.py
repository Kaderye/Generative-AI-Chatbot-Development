from fastapi import FastAPI
from app.routes import router

app = FastAPI(title="RAG Chatbot API")
app.include_router(router)


# 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
