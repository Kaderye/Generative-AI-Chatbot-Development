from fastapi import APIRouter, UploadFile, File, Form
from typing import Optional
from app.utils import file_loader, embedder, vector_store, llm_client, ocr

router = APIRouter()

@router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    chunks, metadata = await file_loader.load_and_chunk(file)
    embeddings = embedder.generate_embeddings(chunks)
    file_id = vector_store.save_to_vector_store(embeddings, chunks, metadata)
    return {"status": "uploaded", "file_id": file_id}

@router.post("/query")
async def query_api(
    question: str = Form(...),
    image_base64: Optional[str] = Form(None)
):
    if image_base64:
        extracted_text = ocr.extract_text_from_base64(image_base64)
        question += "\n" + extracted_text

    query_embedding = embedder.generate_embeddings([question])[0]
    docs = vector_store.search_similar(query_embedding)
    prompt = llm_client.construct_prompt(question, docs)
    answer = llm_client.query_llm(prompt)

    return {
        "question": question,
        "context": [doc["text"] for doc in docs],
        "sources": [doc["source"] for doc in docs],
        "answer": answer
    }
